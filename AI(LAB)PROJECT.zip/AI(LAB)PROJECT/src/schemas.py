from pydantic import BaseModel

class StudentInput(BaseModel):
    ScreenTime: float
    SleepHours: float
    SocialMediaUsage: float
    Age: int
    Gender: str
