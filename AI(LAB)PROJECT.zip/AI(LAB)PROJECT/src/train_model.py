# train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import pickle

# Load cleaned dataset
df = pd.read_csv("../data/processed/students_cleaned.csv")

# Encode Gender
le = LabelEncoder()
df['Gender_Encoded'] = le.fit_transform(df['Gender'])

# Save LabelEncoder
with open("../models/label_encoder.pkl", "wb") as f:
    pickle.dump(le, f)

# Features and target (make sure column names match your CSV)
X = df[['Avg_Daily_Usage_Hours', 'Gender_Encoded']]  # example features
y = df['Addicted_Score']  # target column

# Train RandomForest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# Save the trained model
with open("../models/random_forest_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("Model and LabelEncoder saved correctly!")
