import joblib
import pandas as pd

# Load the trained model
model = joblib.load("../models/random_forest_model.pkl")

def predict_addiction(input_data):
    # Map frontend input to model features used during training
    df = pd.DataFrame([{
        "Daily_Usage_Hours": input_data["ScreenTime"],  # map ScreenTime
        "Gender_Encoded": 1 if input_data["Gender"].lower() == "male" else 0
    }])

    # Make prediction
    pred = model.predict(df)[0]
    
    # Return in readable format
    return {"Addicted": str(pred)}
