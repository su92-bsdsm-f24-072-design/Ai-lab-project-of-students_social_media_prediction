import pandas as pd

def preprocess_data(df):
    # Convert Daily_Usage to numeric
    if "Daily_Usage" in df.columns:
        df["Daily_Usage_Hours"] = df["Daily_Usage"].str.extract('(\d+)').astype(float)
    return df  