from sklearn.preprocessing import LabelEncoder
import joblib

def encode_features(df):
    le = LabelEncoder()
    df["Gender_Encoded"] = le.fit_transform(df["Gender"])
    # Save encoder for API use
    joblib.dump(le, "../models/label_encoder.pkl") 
    return df 


