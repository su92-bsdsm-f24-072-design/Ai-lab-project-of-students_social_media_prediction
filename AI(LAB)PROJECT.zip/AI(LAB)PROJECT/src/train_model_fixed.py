import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# 1. LOAD CLEANED DATA
df = pd.read_csv("../data/processed/students_cleaned.csv")

# 2. SELECT FEATURES & TARGET

# We use these features because they logically affect addiction score
df = df[['Avg_Daily_Usage_Hours',
         'Sleep_Hours_Per_Night',
         'Mental_Health_Score',
         'Age',
         'Gender',
         'Addicted_Score']]

# Rename for your API naming consistency
df = df.rename(columns={
    'Avg_Daily_Usage_Hours': 'ScreenTime',
    'Sleep_Hours_Per_Night': 'SleepHours',
    'Mental_Health_Score': 'SocialMediaUsage'
})

# Features & Target
X = df[['ScreenTime', 'SleepHours', 'SocialMediaUsage', 'Age', 'Gender']]
y = df['Addicted_Score']


# 3. ENCODE GENDER

le = LabelEncoder()
X['Gender'] = le.fit_transform(X['Gender'])


# 4. TRAIN / TEST SPLIT

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


# 5. TRAIN RANDOM FOREST MODEL

model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)


# 6. CHECK ACCURACY

y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("\n==============================")
print("MODEL TRAINED SUCCESSFULLY!")
print(f"Model Accuracy: {accuracy * 100:.2f}%")
print("==============================\n")

# 7. SAVE MODEL + ENCODER

with open("../models/random_forest_model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("../models/label_encoder.pkl", "wb") as f:
    pickle.dump(le, f)

print("Model & LabelEncoder saved successfully!")
