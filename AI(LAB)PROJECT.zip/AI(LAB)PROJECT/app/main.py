import pickle
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel

# Load trained model
with open("C:\\Users\\Fakhar Trader\\Desktop\\AI(LAB)PROJECT\\models\\random_forest_model.pkl", "rb") as f:
    model = pickle.load(f)

# Load the fixed LabelEncoder
with open("C:\\Users\\Fakhar Trader\\Desktop\\AI(LAB)PROJECT\\models\\label_encoder.pkl", "rb") as f:
    le = pickle.load(f)

# Define input schema
class StudentInput(BaseModel):
    ScreenTime: float
    SleepHours: float
    SocialMediaUsage: float
    Age: int
    Gender: str

app = FastAPI(title="Student Addiction Prediction API")

@app.get("/")
def read_root():
    return {"message": "API is working!"}

@app.post("/predict")
def predict(input_data: StudentInput):
    try:
        # Convert input to model features
        X = np.array([[input_data.ScreenTime,
                       input_data.SleepHours,
                       input_data.SocialMediaUsage,
                       input_data.Age,
                       le.transform([input_data.Gender])[0]]])
        pred = model.predict(X)
        return {"Addicted_Score": int(pred[0])}
    except Exception as e:
        return {"error": str(e)}